import { motion } from 'framer-motion';
import { ChevronLeft } from 'lucide-react';

interface BackButtonProps {
  onClick: () => void;
}

const BackButton = ({ onClick }: BackButtonProps) => {
  return (
    <motion.button
      onClick={onClick}
      className="fixed top-6 left-6 z-50 group flex items-center justify-center w-12 h-12 rounded-full border-2 border-primary/50 bg-muted/30 backdrop-blur-sm hover:border-primary hover:bg-primary/20 transition-all duration-300"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 0.3 }}
    >
      <ChevronLeft className="w-6 h-6 text-primary group-hover:text-primary-foreground transition-colors" />
    </motion.button>
  );
};

export default BackButton;
