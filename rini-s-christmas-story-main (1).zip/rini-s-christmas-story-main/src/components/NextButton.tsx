import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';

interface NextButtonProps {
  onClick: () => void;
}

const NextButton = ({ onClick }: NextButtonProps) => {
  return (
    <motion.button
      onClick={onClick}
      className="mt-12 group relative flex items-center justify-center w-16 h-16 rounded-full border-2 border-primary/50 bg-muted/30 backdrop-blur-sm hover:border-primary hover:bg-primary/20 transition-all duration-300"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.8 }}
    >
      <motion.div
        animate={{ x: [0, 5, 0] }}
        transition={{ duration: 1.5, repeat: Infinity }}
      >
        <ChevronRight className="w-8 h-8 text-primary group-hover:text-primary-foreground transition-colors" />
      </motion.div>
      <div className="absolute inset-0 rounded-full bg-primary/20 blur-xl group-hover:bg-primary/30 transition-all" />
    </motion.button>
  );
};

export default NextButton;
