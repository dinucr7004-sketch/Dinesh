import { motion } from 'framer-motion';
import FloatingHearts from '../FloatingHearts';

const PageFive = () => {
  const words = ['I', 'LOVE', 'YOU', 'SINNA', '💞'];

  return (
    <motion.div
      className="min-h-screen flex flex-col items-center justify-center px-6 relative z-10 overflow-hidden"
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5 }}
    >
      <FloatingHearts />
      
      <div className="flex flex-col items-center gap-2">
        {words.map((word, index) => (
          <motion.span
            key={index}
            className={`font-script ${
              word === 'LOVE' || word === 'SINNA' || word === '💞'
                ? 'text-7xl sm:text-9xl md:text-[10rem] text-primary font-bold'
                : 'text-5xl sm:text-7xl md:text-8xl text-foreground'
            }`}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ 
              opacity: 1, 
              scale: 1,
            }}
            transition={{
              duration: 0.8,
              delay: index * 0.4,
              type: 'spring',
              stiffness: 150,
            }}
            style={{
              textShadow: word === 'LOVE' || word === 'SINNA' || word === '💞'
                ? '0 0 60px hsl(var(--primary) / 0.8), 0 0 120px hsl(var(--primary) / 0.4)'
                : '0 0 30px hsl(var(--foreground) / 0.3)',
            }}
          >
            {word === '💞' ? (
              <motion.span
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="inline-block"
              >
                {word}
              </motion.span>
            ) : (
              word
            )}
          </motion.span>
        ))}
      </div>

      <motion.p
        className="mt-12 font-elegant text-xl sm:text-2xl text-muted-foreground italic text-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2.5 }}
      >
        Forever and Always ✨
      </motion.p>

      {/* Glow effects */}
      <motion.div
        className="absolute inset-0 pointer-events-none"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
      >
        <div 
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full animate-pulse"
          style={{
            background: 'radial-gradient(circle, hsl(var(--primary) / 0.2) 0%, transparent 60%)',
          }}
        />
      </motion.div>

      {/* Sparkles */}
      {Array.from({ length: 20 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-accent rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ 
            opacity: [0, 1, 0],
            scale: [0, 1, 0],
          }}
          transition={{
            duration: 2,
            delay: 2 + Math.random() * 2,
            repeat: Infinity,
            repeatDelay: Math.random() * 3,
          }}
        />
      ))}
    </motion.div>
  );
};

export default PageFive;
