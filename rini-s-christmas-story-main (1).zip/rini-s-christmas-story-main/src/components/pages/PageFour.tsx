import { motion } from 'framer-motion';
import NextButton from '../NextButton';

interface PageFourProps {
  onNext: () => void;
}

const PageFour = ({ onNext }: PageFourProps) => {
  const message = `This Christmas I just want you to know how special you are to me 🥰. You are the Person I don't want to lose in my life. And you're not just a part of my life, you're the reason it feels complete.. and I will never stop Loving you 🫀🌍...`;

  return (
    <motion.div
      className="min-h-screen flex flex-col items-center justify-center px-6 py-12 relative z-10"
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -100 }}
      transition={{ duration: 0.5 }}
    >
      <motion.h2
        className="font-script text-5xl sm:text-7xl md:text-8xl text-foreground mb-8"
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        style={{
          textShadow: '0 0 30px hsl(var(--primary) / 0.5)',
        }}
      >
        Hey Cutie 🤗
      </motion.h2>

      <motion.div
        className="max-w-2xl mx-auto"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.4 }}
      >
        <div 
          className="relative p-8 sm:p-12 rounded-3xl backdrop-blur-sm"
          style={{
            background: 'linear-gradient(135deg, hsl(var(--card) / 0.8) 0%, hsl(var(--muted) / 0.5) 100%)',
            boxShadow: '0 25px 50px -12px hsl(var(--primary) / 0.25)',
          }}
        >
          <motion.div
            className="absolute -top-4 -left-4 text-4xl"
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            💝
          </motion.div>
          <motion.div
            className="absolute -bottom-4 -right-4 text-4xl"
            animate={{ rotate: [0, -10, 10, 0] }}
            transition={{ duration: 3, repeat: Infinity, delay: 0.5 }}
          >
            💝
          </motion.div>

          <p className="font-elegant text-xl sm:text-2xl md:text-3xl text-foreground leading-relaxed text-center italic">
            {message}
          </p>
        </div>
      </motion.div>

      <motion.div
        className="mt-8 flex gap-3"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
      >
        {['💕', '💗', '💖', '💗', '💕'].map((heart, i) => (
          <motion.span
            key={i}
            className="text-2xl sm:text-3xl animate-pulse-glow"
            style={{ animationDelay: `${i * 0.2}s` }}
          >
            {heart}
          </motion.span>
        ))}
      </motion.div>

      <NextButton onClick={onNext} />
    </motion.div>
  );
};

export default PageFour;
