import { motion } from 'framer-motion';
import NextButton from '../NextButton';

interface PageOneProps {
  onNext: () => void;
}

const PageOne = ({ onNext }: PageOneProps) => {
  return (
    <motion.div
      className="min-h-screen flex flex-col items-center justify-center px-6 relative z-10"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, x: -100 }}
      transition={{ duration: 0.5 }}
    >
      <motion.h1
        className="font-script text-6xl sm:text-8xl md:text-9xl text-foreground glow-effect"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
      >
        Hey Rini
      </motion.h1>
      
      <motion.div
        className="mt-8 flex items-center gap-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        <span className="text-2xl">✨</span>
        <span className="text-muted-foreground font-elegant text-xl italic">
          I have something special for you
        </span>
        <span className="text-2xl">✨</span>
      </motion.div>

      <NextButton onClick={onNext} />
    </motion.div>
  );
};

export default PageOne;
