import { motion } from 'framer-motion';
import NextButton from '../NextButton';
import FloatingHearts from '../FloatingHearts';

interface PageThreeProps {
  onNext: () => void;
}

const PageThree = ({ onNext }: PageThreeProps) => {
  const words = ['You', 'are', 'My', 'Cutest', 'Gift', '💗'];

  return (
    <motion.div
      className="min-h-screen flex flex-col items-center justify-center px-6 relative z-10"
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -100 }}
      transition={{ duration: 0.5 }}
    >
      <FloatingHearts />
      
      <div className="flex flex-col items-center gap-4">
        {words.map((word, index) => (
          <motion.span
            key={index}
            className={`font-script ${
              word === 'Cutest' || word === 'Gift' || word === '💗'
                ? 'text-6xl sm:text-8xl md:text-9xl text-primary'
                : 'text-4xl sm:text-6xl md:text-7xl text-foreground'
            }`}
            initial={{ 
              opacity: 0, 
              scale: 0,
              rotate: index % 2 === 0 ? -20 : 20 
            }}
            animate={{ 
              opacity: 1, 
              scale: 1,
              rotate: 0 
            }}
            transition={{
              duration: 0.6,
              delay: index * 0.3,
              type: 'spring',
              stiffness: 200,
            }}
            style={{
              textShadow: word === 'Cutest' || word === 'Gift' || word === '💗'
                ? '0 0 40px hsl(var(--primary) / 0.6)'
                : '0 0 20px hsl(var(--foreground) / 0.3)',
            }}
          >
            {word}
          </motion.span>
        ))}
      </div>

      <motion.div
        className="absolute inset-0 pointer-events-none"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
      >
        <div 
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full"
          style={{
            background: 'radial-gradient(circle, hsl(var(--primary) / 0.15) 0%, transparent 70%)',
          }}
        />
      </motion.div>

      <NextButton onClick={onNext} />
    </motion.div>
  );
};

export default PageThree;
