import { motion } from 'framer-motion';
import NextButton from '../NextButton';

interface PageTwoProps {
  onNext: () => void;
}

const PageTwo = ({ onNext }: PageTwoProps) => {
  const letters = "Happy Christmas🎁".split('');

  return (
    <motion.div
      className="min-h-screen flex flex-col items-center justify-center px-6 relative z-10"
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -100 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex flex-wrap justify-center">
        {letters.map((letter, index) => (
          <motion.span
            key={index}
            className="font-script text-5xl sm:text-7xl md:text-8xl text-foreground"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.5,
              delay: index * 0.08,
              ease: 'easeOut',
            }}
            style={{
              textShadow: '0 0 30px hsl(var(--primary) / 0.5)',
            }}
          >
            {letter === ' ' ? '\u00A0' : letter}
          </motion.span>
        ))}
      </div>

      <motion.div
        className="mt-8 flex gap-4"
        initial={{ opacity: 0, scale: 0 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 1.5, duration: 0.5 }}
      >
        {['🎄', '⭐', '🎅', '❄️', '🎄'].map((emoji, i) => (
          <motion.span
            key={i}
            className="text-3xl sm:text-4xl"
            animate={{ y: [0, -10, 0] }}
            transition={{
              duration: 2,
              delay: i * 0.2,
              repeat: Infinity,
            }}
          >
            {emoji}
          </motion.span>
        ))}
      </motion.div>

      <NextButton onClick={onNext} />
    </motion.div>
  );
};

export default PageTwo;
