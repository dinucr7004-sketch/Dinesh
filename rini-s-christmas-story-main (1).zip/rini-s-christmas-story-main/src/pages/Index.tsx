import { useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import Snowfall from '../components/Snowfall';
import BackButton from '../components/BackButton';
import PageOne from '../components/pages/PageOne';
import PageTwo from '../components/pages/PageTwo';
import PageThree from '../components/pages/PageThree';
import PageFour from '../components/pages/PageFour';
import PageFive from '../components/pages/PageFive';

const Index = () => {
  const [currentPage, setCurrentPage] = useState(1);

  const nextPage = () => {
    setCurrentPage((prev) => Math.min(prev + 1, 5));
  };

  const prevPage = () => {
    setCurrentPage((prev) => Math.max(prev - 1, 1));
  };

  return (
    <div className="min-h-screen bg-romantic-gradient overflow-hidden relative">
      <Snowfall />
      
      {currentPage > 1 && <BackButton onClick={prevPage} />}
      
      <AnimatePresence mode="wait">
        {currentPage === 1 && <PageOne key="page1" onNext={nextPage} />}
        {currentPage === 2 && <PageTwo key="page2" onNext={nextPage} />}
        {currentPage === 3 && <PageThree key="page3" onNext={nextPage} />}
        {currentPage === 4 && <PageFour key="page4" onNext={nextPage} />}
        {currentPage === 5 && <PageFive key="page5" />}
      </AnimatePresence>
    </div>
  );
};

export default Index;
